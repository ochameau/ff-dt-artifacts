/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

define({
  name: 'dupe'
});

// This is wrong and should not be allowed. Only one call to
// define per file.
define([], function () {
  return {
    name: 'dupe2'
  };
});
