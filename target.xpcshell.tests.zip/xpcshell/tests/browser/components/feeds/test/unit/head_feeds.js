var Cc = Components.classes;
var Ci = Components.interfaces;
var Cr = Components.results;

var ios = Cc["@mozilla.org/network/io-service;1"].getService(Ci.nsIIOService);
