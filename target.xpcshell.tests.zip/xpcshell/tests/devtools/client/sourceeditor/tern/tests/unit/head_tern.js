"use strict";
var { classes: Cc, interfaces: Ci, utils: Cu, results: Cr } = Components;
const { require } = Cu.import("resource://devtools/shared/Loader.jsm", {});
