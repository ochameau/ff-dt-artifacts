"use strict";

function f() {
  var a = 1;            var c = 3;
}
