"use strict";

function f() {
  for (var i = 0; i < 1; ++i) {
    ;
  }
}
