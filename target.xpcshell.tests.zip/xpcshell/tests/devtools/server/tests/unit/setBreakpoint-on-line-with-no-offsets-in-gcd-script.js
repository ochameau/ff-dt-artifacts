"use strict";

function f() {}

(function () {
  var a = 1;

  var c = 3;
})();
